-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : jeu. 24 avr. 2025 à 13:43
-- Version du serveur :  5.7.31
-- Version de PHP : 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `ma_veille_tech`
--

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `date_creation` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nom` (`nom`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `categories`
--

INSERT INTO `categories` (`id`, `nom`, `date_creation`) VALUES
(1, 'Frameworks Frontend', '2025-04-24 07:29:11'),
(2, 'Frameworks Backend', '2025-04-24 07:29:11'),
(3, 'Langages de Programmation', '2025-04-24 07:29:11'),
(4, 'Bases de Données', '2025-04-24 07:29:11'),
(5, 'Outils DevOps', '2025-04-24 07:29:11'),
(6, 'IA et Machine Learning', '2025-04-24 07:29:11'),
(7, 'Bibliothèques JS', '2025-04-24 07:29:11'),
(8, 'Concepts Généraux', '2025-04-24 07:29:11'),
(9, 'Génération des rapports', '2025-04-24 08:05:27'),
(10, 'IA pour Design', '2025-04-24 08:05:27'),
(11, 'Outils de design graphique', '2025-04-24 08:05:27');

-- --------------------------------------------------------

--
-- Structure de la table `decouvertes`
--

DROP TABLE IF EXISTS `decouvertes`;
CREATE TABLE IF NOT EXISTS `decouvertes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `liens_utiles` text,
  `categorie_id` int(11) NOT NULL,
  `date_decouverte` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `categorie_id` (`categorie_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `decouvertes`
--

INSERT INTO `decouvertes` (`id`, `titre`, `description`, `liens_utiles`, `categorie_id`, `date_decouverte`) VALUES
(1, 'Bolt IA', 'Une intelligence artificielle qui a la possibilité de créer un projet React avec Tailwind CSS avec une base de données Supabase en ligne.', 'https://bolt.new', 6, '2025-04-24 07:37:21'),
(3, 'JasperSoft Studio', 'C\'est un outils Java qui permet de faire les Etats (les actes) de manière graphique permettant de rendre dynamique la géneration des états lors de l\'utilisation de Java ou d\'un framework Java (Par exemple : SpringBoot)', 'https://community.jaspersoft.com', 9, '2025-04-24 10:17:17'),
(4, 'Blackbox IA', 'Une intelligence artificielle qui permet de convertir une image en une application (le code frontend qui donnera le même rendu que l\'image)', 'https://www.blackbox.ai', 6, '2025-04-24 10:41:35'),
(5, '🐳Docker', 'Docker est un outil qui permet de créer, déployer et exécuter des applications dans des conteneurs. Cela garantit que ton application fonctionne de la même manière, peu importe l\'environnement (développement, test, production).', 'https://www.docker.com', 5, '2025-04-24 12:00:34'),
(6, '🌐 Angular', 'Angular est un framework JavaScript développé par Google pour créer des applications web dynamiques et interactives. Il facilite la création de sites web modernes avec une structure solide.', 'https://angular.dev', 1, '2025-04-24 12:01:39'),
(7, '☕Spring Boot', 'Spring Boot est un framework Java basé sur Spring qui simplifie le développement d\'applications web et de services REST. Il permet de créer des applications prêtes pour la production avec un minimum de configuration.', 'https://spring.io/projects/spring-boot', 2, '2025-04-24 12:03:16'),
(8, '🤖 Claude IA', 'Claude est un assistant d\'intelligence artificielle développé par Anthropic. Il est conçu pour être sûr, précis et utile, capable d\'aider dans des tâches telles que la rédaction, la programmation, l\'analyse de documents et plus encore.', 'https://claude.ai', 6, '2025-04-24 12:04:19'),
(9, '🧠 DeepSeek IA', 'DeepSeek est une intelligence artificielle chinois très avancé aussi et qui est très puissant dans plusieurs domaines.', 'https://www.deepseek.com', 6, '2025-04-24 12:07:53');

-- --------------------------------------------------------

--
-- Structure de la table `decouverte_tag`
--

DROP TABLE IF EXISTS `decouverte_tag`;
CREATE TABLE IF NOT EXISTS `decouverte_tag` (
  `decouverte_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  PRIMARY KEY (`decouverte_id`,`tag_id`),
  KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `decouverte_tag`
--

INSERT INTO `decouverte_tag` (`decouverte_id`, `tag_id`) VALUES
(6, 1),
(7, 2),
(1, 8),
(3, 9),
(3, 10),
(4, 11),
(5, 12),
(6, 13),
(7, 13),
(8, 14),
(9, 15);

-- --------------------------------------------------------

--
-- Structure de la table `tags`
--

DROP TABLE IF EXISTS `tags`;
CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `date_creation` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nom` (`nom`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `tags`
--

INSERT INTO `tags` (`id`, `nom`, `date_creation`) VALUES
(1, 'Frontend', '2025-04-24 07:44:21'),
(2, 'Backend', '2025-04-24 07:44:21'),
(3, 'IA', '2025-04-24 07:44:21'),
(4, 'DevOps', '2025-04-24 07:44:21'),
(5, 'Base de Données', '2025-04-24 07:44:21'),
(6, 'Utile au Quotidien', '2025-04-24 07:44:21'),
(7, 'À Explorer', '2025-04-24 07:44:21'),
(8, 'IA pour React JS', '2025-04-24 07:57:30'),
(9, 'Rapport', '2025-04-24 08:08:12'),
(10, 'Etats', '2025-04-24 08:08:12'),
(11, 'IA image to App', '2025-04-24 10:41:35'),
(12, 'Conteneurisation', '2025-04-24 12:00:34'),
(13, 'web', '2025-04-24 12:01:39'),
(14, 'IA très avancé', '2025-04-24 12:04:19'),
(15, 'IA polyvalent', '2025-04-24 12:07:53');

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `decouvertes`
--
ALTER TABLE `decouvertes`
  ADD CONSTRAINT `decouvertes_ibfk_1` FOREIGN KEY (`categorie_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `decouverte_tag`
--
ALTER TABLE `decouverte_tag`
  ADD CONSTRAINT `decouverte_tag_ibfk_1` FOREIGN KEY (`decouverte_id`) REFERENCES `decouvertes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `decouverte_tag_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
